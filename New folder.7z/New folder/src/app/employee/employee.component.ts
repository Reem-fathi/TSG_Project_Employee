import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CredentialsService } from '@app/auth';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})
export class EmployeeComponent implements OnInit {
  employee: any;
  

  constructor(private http:HttpClient,private credentialService:CredentialsService) { }
 

  ngOnInit(): void {
    this.http.get(`http://localhost:8080/auth/getDetail/${sessionStorage.getItem("email")}`,{ headers: { Authorization: `Bearer ${this.credentialService.credentials}`}}).subscribe(res=>{
      console.log("res",res);     
      this.employee = res;
    })
  }
}
