import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ViewService } from './view.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss'],
})
export class ViewComponent implements OnInit {
  credentialsService: any;

  constructor(private viewService: ViewService,private _router:Router) {}
  
  emps: any = [];
  auth: any;

  ngOnInit(): void {
    this.viewService.getEmployee().subscribe((response: any) => {
      console.log(response);
      this.emps = response;
    });
  }

  // deleteEmployee(id: any) {
  
  //   this.viewService.deleteEmployee(id).subscribe((res: any) => {
  
  //     console.log(res);
  //   });
  // }


   deleteEmployee(empId : any) { 
    //    console.log('delete', id);  
    alert("Are you sure want to delete id ${empId}..?")   
      this.viewService.deleteEmployee(empId
        ).subscribe((response: any) =>
       {      console.log('after', response);     
        this.viewService.getEmployee().subscribe((response: any) =>
         {       
            console.log(response);      
              this.emps = response;    
            });   
         }); 
         }
   edit(id: any) 
         {    console.log(id);  
             this._router.navigate(['edit'], { queryParams: { id: id } });  }
       
       
       }
         

