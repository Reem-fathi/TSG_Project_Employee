import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CredentialsService } from '@app/auth';
import { Observable } from 'rxjs';

export interface AddContext {
  name: string;
  email: string;
  project: string;
  address: string;
  skill: string;
  dob: string;
  joiningDate: string;
  salary: number;
}

@Injectable({
  providedIn: 'root',
})
export class AddemployeeService {
  constructor(private http: HttpClient, private credentialService: CredentialsService) {}
  getEmployee(): Observable<any> {
    return this.http.get('/auth/getEmployee', {
      headers: { Authorization: `Bearer ${this.credentialService.credentials}` },
    });
  }
  addEmployee(requestObj: AddContext): Observable<any> {
    console.log('employee1', requestObj);
    return this.http.post('/auth/addEmployee', requestObj, {
      headers: { Authorization: `Bearer ${this.credentialService.credentials}` },
    });
  }
  deleteEmployee(id:any):Observable<any> {    
       return this.http.delete<any>(`/auth/deleteEmployee/${id}`,{headers:{"Authorization": `Bearer ${this.credentialService.credentials}`}})
    }
    updateEmployee(id: any, reqObj: AddContext): Observable<any> {
      return this.http.put(`/auth/${id}`, reqObj, {
        headers: { Authorization: `Bearer ${this.credentialService.credentials}` },
      });
    }
  

}
