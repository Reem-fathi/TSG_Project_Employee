import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AddemployeeService } from './addemployee.service';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.scss'],
})
export class AddemployeeComponent implements OnInit {
  addForm!: FormGroup;
  employee: any;

  constructor(
    private addEmployeeService: AddemployeeService,
    private formBuilder: FormBuilder,
    private router: Router
  ) {
    this.employeeForm();
  }

  ngOnInit(): void {
    this.addEmployeeService.getEmployee().subscribe((response: any) => {
      console.log('category', response);
      this.employee = response;
    });
  }
  addEmp() {
    if (this.addForm.valid) {
      console.log('form values', this.addForm.value);
      const reqObj = {
        name: this.addForm.value.name,
        email: this.addForm.value.email,
        project: this.addForm.value.project,
        address: this.addForm.value.address,
        skill: this.addForm.value.skill,
        dob: this.addForm.value.dob,
        joiningDate: this.addForm.value.joiningDate,
        salary: this.addForm.value.salary,
      };
      console.log('req', reqObj);

      this.addEmployeeService.addEmployee(reqObj).subscribe((response: 'successful') => {
        console.log('after', response);
        this.router.navigate(['/home']);
      });
    }
  }

  private employeeForm() {
    this.addForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      project: ['', Validators.required],
      address: ['', Validators.required],
      skill: ['', Validators.required],
      dob: ['', Validators.required],
      joiningDate: ['', Validators.required],
      salary: ['', Validators.required],
    });
  }

}


 
 
 
