import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddemployeeComponent } from '@app/addemployee/addemployee.component';
import { HomeComponent } from '@app/home/home.component';
import { ViewComponent } from '@app/view/view.component';

import { marker } from '@biesbjerg/ngx-translate-extract-marker';

import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent, data: { title: marker('Login') } },
  { path: 'register', component: RegisterComponent, data: { title: marker('Register') } },
  // { path: 'addemployee', component: AddemployeeComponent, data: { title: marker('AddEmployee') } },
  // { path: 'view', component: ViewComponent, data: { title: marker('View') } },
  // { path: 'home', component: HomeComponent, data: { title: marker('Home') } },
  { path: '', component: LoginComponent, data: { title: marker('Login') } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class AuthRoutingModule {}
