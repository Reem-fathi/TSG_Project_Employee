import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { marker } from '@biesbjerg/ngx-translate-extract-marker';

import { HomeComponent } from './home.component';
import { Shell } from '@app/shell/shell.service';
import { AddemployeeComponent } from '@app/addemployee/addemployee.component';
import { ViewComponent } from '@app/view/view.component';
import { LoginComponent } from '@app/auth/login/login.component';
import { EmployeeComponent } from '@app/employee/employee.component';
import { EditComponent } from '@app/edit/edit.component';

const routes: Routes = [
  Shell.childRoutes([
    // { path: '', redirectTo: '/home', pathMatch: 'full' },
    // { path: 'home', component: HomeComponent, data: { title: marker('Home') } },
    { path: 'addemployee', component: AddemployeeComponent, data: { title: marker('AddEmployee') } },
    { path: 'view', component: ViewComponent, data: { title: marker('View') } },
    { path: 'home', component: HomeComponent, data: { title: marker('Home') } },
    { path: '', component: LoginComponent, data: { title: marker('Login') } },
    { path: 'employee', component: EmployeeComponent, data: { title: marker('Employee') } },
    { path: 'edit', component: EditComponent, data: { title: marker('Edit') } },
  ]),
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class HomeRoutingModule {}
