import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CredentialsService } from '@app/auth';
import { Observable } from 'rxjs';




export interface EditContext {
  name: string;
  email:string; 
  project:string;
  address: string;
  skill: string;
  dob: string;
  joiningDate:string;
  salary:number;
  // remember?: boolean;
}


@Injectable({
  providedIn: 'root'
})
export class EditService {

  constructor(private http: HttpClient, private credentialService: CredentialsService) {}
  getOneEmployee(empId: any): Observable<any> {
    console.log('query', empId);
    return this.http.get(`/auth/getEmployee/${empId}`, {
      headers: { Authorization: `Bearer ${this.credentialService.credentials}` },
    });
  }

  // getCategory(): Observable<any> {
  //   return this.http.get('/category', { headers: { Authorization: `Bearer ${this.credentialService.credentials}` } });
  // }

  updateEmployee(empId: any, reqObj: EditContext): Observable<any> {
    return this.http.put(`/auth/updateEmployee/${empId}`, reqObj, {
      headers: { Authorization: `Bearer ${this.credentialService.credentials}` },
    });
  }
  getEmployeeList(): Observable<any> {
    return this.http.get('/auth/getEmployee', { headers: { Authorization: `Bearer ${this.credentialService.credentials}` } });
  }


}



