import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,FormControl,Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EditService } from './edit.service';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit {
  category: any;
  editForm!: FormGroup;
  employees: any;



  constructor(
    private editService: EditService,
    private formBuilder: FormBuilder,
    private _router: Router,
    private route: ActivatedRoute,

  ) { }
  data: any;
  ngOnInit(): void {

    const empId = this.route.snapshot.queryParamMap.get('id');
    this.getEditEmployee(empId)
    // this.editForm = new FormGroup({
    //     name: new FormControl(response.name),
    //     email: ['', Validators.required],
    //     project: ['', Validators.required],
    //     address: ['', Validators.required],
    //     skill: ['', Validators.required],
    //     dob: ['', Validators.required],
    //     joiningDate: ['', Validators.required],
    //     salary: ['', Validators.required],
    //   });


}
getEditEmployee(empId: any){
  console.log(empId)
  this.editService.getOneEmployee(empId).subscribe((response:any)=>{
    console.log("sdlkf",response)
    this.data=response;
    this.editForm = new FormGroup({

      name:new FormControl(response.name),
      email:new FormControl(response.email),
      project:new FormControl(response.project),
      address:new FormControl(response.address),
      skill:new FormControl(response.skill),
      dob:new FormControl(response.dob),
      joiningDate:new FormControl(response.joiningDate),
      salary:new FormControl(response.salary)

    })
    console.log("response",response)
  }
  )
}
   

  // edit() {
  //   const id = this.route.snapshot.queryParamMap.get('id');
  //   console.log('id ', id);
  //   const reqObj = {
    
  //     name: this.editForm.value.name,
  //     email: this.editForm.value.email,
  //     project:this.editForm.value.project,
  //     address: this.editForm.value.address,
  //     skill: this.editForm.value.skill,
  //     dob: this.editForm.value.dob,
  //     joiningDate:this.editForm.value.joiningDate,
  //     salary:this.editForm.value.salary,
  //   };
  //   console.log('req', reqObj);
  //   this.editService.updateEmployee(id, reqObj).subscribe((response: any) => {
  //     console.log('after put', response);
  //     this.editService.getEmployeeList().subscribe((response: any) => {
  //       console.log(response);
  //       this.employees = response;
       
  //       this._router.navigate(['/view']);
  //     });
  //   });
  // }



  }

